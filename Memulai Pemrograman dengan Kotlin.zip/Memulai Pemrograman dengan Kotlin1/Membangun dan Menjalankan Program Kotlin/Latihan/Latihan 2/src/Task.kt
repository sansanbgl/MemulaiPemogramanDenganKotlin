fun main() {
    println("Kotlin,\n" +
            "is Awesome!")
}