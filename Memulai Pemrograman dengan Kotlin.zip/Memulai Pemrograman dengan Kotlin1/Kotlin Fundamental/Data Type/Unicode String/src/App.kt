// main function
fun main() {
    val name = "Unicode test: \u0394"
    print(name)
}